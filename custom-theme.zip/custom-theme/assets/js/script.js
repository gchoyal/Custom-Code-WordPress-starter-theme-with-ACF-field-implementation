(function($) {
	"use strict"; // Start of use strict

	$(document).ready(function(){
		
		if( $(window).width() < 768 ){
			
			$('.woocommerce-page .left-sidebar-filter h4').click(function() {
				$(this).next('ul').toggle();
				return false;
			});
			
		}
		
		$('#single-product-qty-input').change(function(){
			var productQty = $(this).val();
			$('.add_to_cart_button').attr( 'data-quantity', productQty );
			return false;
		});
		
		$(window).scroll(function() {
			
			var scrolled = $(window).scrollTop(); 
			
			//nav
			/*if( scrolled > 10 ) {
				$('header').addClass('fixed-top');
			}else{
				$('header').removeClass('fixed-top');
			}*/
			
			//backtotop
			if( scrolled > 600 ) {
				$('#back-to-top').show();
			}else{
				$('#back-to-top').hide();
			}
			
		});
		
		$('body').imagesLoaded(function () {
			$('.page-loader').hide();
			
			$('.grid').masonry({
              // options
              itemSelector: '.grid-item',
              layoutMode: 'fitRows'
            });
			
		});

		// Smooth scrolling using jQuery easing
		$('a.js-scroll-trigger[href*="#"]:not([href="#"])').click(function() {
			if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
				var target = $(this.hash);
				target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
				if (target.length) {
					$('html, body').animate({
						scrollTop: (target.offset().top - 56)
					}, 1000 );
					return false;
				}
			}
		});
		
		
		$('.attribute').click(function() {
			
			$(this).parent().find('.product-filter-atrr-loader').show();
			
			$(this).toggleClass('active');
			
			//change checkbox
			if( $(this).find('i').hasClass('fa-square') ){
				$(this).find('i.fa-square').addClass('fa-check-square').removeClass('fa-square');
			}else{
				$(this).find('i.fa-check-square').addClass('fa-square').removeClass('fa-check-square');
			}
			
			update_product_listings();
			return false;
			
		});
		
		$('.filter-input-select').change(function() {
			$(this).next().show();
			update_product_listings();
			return false;
		});		
		
		$(document).on( 'click', '.woocommerce .pagination .page-link', function() {
			var pageno = $(this).attr('pageno');
			update_product_listings(pageno);
			return false;
			
		});
		
		$('#shop-filter-link-mobile').click(function() {
			$('.shop-filter-container-mobile').toggle();
			return false;
		});
		
		function update_product_listings(pageno=''){
			
			$('.page-loader').show();
			$(".product-listing-row").html('<div style="width:100%;text-align: center;padding:15px;margin-top:45px;font-size: 30px;"><i class="fas fa-circle-notch fa-spin"></i></div>');
			
			//Cat
			var activeCategory = $('.category_link.active > a').attr('cat_id');
			
			//get all active Attr
			var aryActiveAttr = [];
			$( ".attribute.active" ).each(function( index ) {
				var objSingleAttr = {};
				objSingleAttr['attribute_name'] = $( this ).attr('attribute_name');
				objSingleAttr['attribute_term'] = $( this ).attr('attribute_term');
				aryActiveAttr.push(objSingleAttr);
			});

			//Filter 
			var per_page_product = $('#per-page-product').val();
			var sort_by = $('#sort-by').val();
			
			$.ajax({
				type : "post",
				url : ajax_url,
				data : { action: "product_listing_refresh", 'activeCategory' : activeCategory, 'aryActiveAttr': aryActiveAttr, 'per_page_product': per_page_product, 'sort_by': sort_by, 'pageno': pageno },
				success: function(response) {
					$(".product-listing-row").html(response);
					$('.page-loader').hide();
					$('.product-filter-atrr-loader').hide();
					
					$('html, body').animate({
						scrollTop: $("#main").offset().top
					}, 400);
					
				},
				error: function(response) {
					console.log( 'Error: '+response );
					$('.page-loader').hide();
					$('.product-filter-atrr-loader').hide();
				}
			});

			console.log( 'SENDIN: Cat:'+activeCategory+', Attri:'+aryActiveAttr+', per_page_product: '+per_page_product+', sort_by:'+sort_by );
			
		}
		
		// Closes responsive menu when a scroll trigger link is clicked
		$('.js-scroll-trigger').click(function() {
			$('.navbar-collapse').collapse('hide');
		});
		
		$('.search-link').click(function() {
			$('#search-form-container').show();
		});
		
		$('.search-close').click(function() {
			$('#search-form-container').hide();
		});
		
		var startWindowScroll;
		// Magnific popup calls
		$('.popup-gallery').magnificPopup({
			delegate: 'a',
			type: 'image',
			closeOnContentClick: false,
			closeBtnInside: false,
			fixedContentPos: true,
			midClick: true,
			mainClass: 'mfp-with-zoom mfp-img-mobile',
			image: {
				verticalFit: true,
				titleSrc: function(item) {
					return item.el.attr('title');
				}
			},
			gallery: {
				enabled: true
			},
			zoom: {
				enabled: true,
				duration: 300, // don't foget to change the duration also in CSS
				opener: function(element) {
					return element.find('img');
				}
			},
			callbacks: {
				open: function() {
					$('html').addClass('no-scrollbar');
					$('body').addClass('no-scrollbar');
					startWindowScroll = $(window).scrollTop();
					$('html').addClass('mfp-helper');
				},
				close: function() {
					$('html').removeClass('no-scrollbar');
					$('body').removeClass('no-scrollbar');
					$('html').removeClass('mfp-helper');
					setTimeout(function(){
					  $('body').animate({ scrollTop: startWindowScroll }, 0);
					}, 0);
				}
			}
			
		});
		
		$(".center").slick({
			lazyLoad: 'ondemand',
			dots: true,
			infinite: true,
			centerMode: false,
			slidesToShow: 5,
			slidesToScroll: 5,
			autoplay: false,
			autoplaySpeed: 500,
			rows: 1,
			zIndex: 1,
			responsive: [
				{
				  breakpoint: 1024,
				  settings: {
					slidesToShow: 5,
					slidesToScroll: 5
				  }
				},
				{
				  breakpoint: 767,
				  settings: {
					slidesToShow: 3,
					slidesToScroll: 3
				  }
				},
				{
				  breakpoint: 480,
				  settings: {
					slidesToShow: 2,
					slidesToScroll: 2
				  }
				}
				// You can unslick at a given breakpoint now by adding:
				// settings: "unslick"
				// instead of a settings object
			  ]
		});


	});

})(jQuery); // End of use strict