<?php get_header(); ?>
	
	<section class="section" >
	  <div class="container">
		<div class="row">
		  <div class="col-lg-12 mx-auto text-center">
				
				<h1>Oops!</h1>
				
                <h2>404 Not Found</h2>
				
                <div class="error-details mt-3 mb-3">Sorry, an error has occured, Requested page not found!</div>
                
				<div class="error-actions mt-3 mb-3">
                    <a href="<?php echo home_url(); ?>" class="btn btn-primary btn-lg">Take Me Home </a>
					
                </div>
			
		  </div>
		</div>
	  </div>
	</section>
	
<?php get_footer(); ?>