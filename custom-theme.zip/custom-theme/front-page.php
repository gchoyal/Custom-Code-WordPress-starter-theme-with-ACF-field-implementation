<?php get_header(); ?>
	
		<div id="home-slider" class="carousel carousel-fade slide" data-ride="carousel">

		  <div class="carousel-inner">
			
			<?php if( have_rows('slide') ):
			    $i=1;
			    while ( have_rows('slide') ) : the_row(); ?>
			    
			<div class="carousel-item overlay <?php if( $i == 1 ){ echo 'active'; } ?>">
			  
			  <?php 
			  
			  $img = get_sub_field('image');
			  
			  img( $img, '', '', 'Slider Image' ); ?>
			  
			  <div class="carousel-caption">
					<div class="col-md-12 slide-content-container">
						<h1 class="heading"><?php the_sub_field('heading_html'); ?></h1>
						<a href="<?php the_sub_field('button_link'); ?>" class="browse-link"><?php the_sub_field('button_text'); ?></a>
					</div>
				</div>
			</div>
			
			<?php $i++; endwhile; endif; ?>
			
			
		  </div>

		  <a class="carousel-control-prev" href="#home-slider" data-slide="prev"><span><i class="fal fa-angle-left"></i></span></a>
		  <a class="carousel-control-next" href="#home-slider" data-slide="next"><span><i class="fal fa-angle-right"></i></span></a>

		</div>
		
		<section class="section" >
		  <div class="container">
			<div class="row">
			  <div class="col-lg-12 mx-auto text-left">
				
				<div class="section-header text-center">
					<p class="color-primary">Just in to store</p>
					<h2 class="section-heading heading">Our Products</h2>
					<p>Find our best products</p>
				</div>
				
				<div class="row product-listing-row">
					
					<?php if( isset($_GET['add-to-cart']) && intval($_GET['add-to-cart']) >0 ){ ?>
					<div class="col-md-12 col-sm-12">
						<?php wc_print_notices(); ?>
					</div>
					<?php } ?>
	
					<?php 
					
					query_posts('post_type=product&post_status=publish&orderby=date&posts_per_page=12');
					
					if( have_posts() ){
					
					while( have_posts() ){ the_post();
					
						single_product();
					
					} } 
					
					wp_reset_query(); ?>
					
				</div>
				
			  </div>
			</div>
		  </div>
		</section>
		
		<section class="section section-graphic-background" style="background-image: url('https://cdn.pixabay.com/photo/2017/08/01/13/36/computer-2565478_960_720.jpg');" >
		  
		  <div class="section-overlay"></div>
		  
		  <div class="container py-5">
			<div class="row">
			  <div class="col-lg-12 mx-auto text-left">
				
				<div class="page-content text-center">

					<h2 class="section-heading heading text-white undrline-heading-center">Heading</h2>
					
					<p class="text-white">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					
				</div>
				
			  </div>
			</div>
		  </div>
		</section>
		
		<section class="section background-gray" >
		  <div class="container">
			<div class="row">
			  <div class="col-12 mx-auto text-center">
				
				<div class="section-header text-center">
					<h2 class="section-heading heading">Trusted by</h2>
				</div>
				
				<div class="col-12">
				<div class="center slider">
					
					<?php if( have_rows('bottom_slider') ):
							$i=1;
							while ( have_rows('bottom_slider') ) : the_row(); ?>
						
							<div class="img-section">
								<?php img( get_sub_field('image')['sizes']['medium'] , '', '', 'logo' ); ?>
							</div>
							
					<?php $i++; endwhile; endif; ?>
									
				</div>
				</div>
				
			  </div>
			</div>
		  </div>
		</section>
		
		<section class="section pb-0" >
		  <div class="container">
			<div class="row">
			  <div class="col-lg-12 mx-auto text-left">
				
				<div class="section-header text-center">
					<p><a href="#" class="color-primary">Follow us @</a></p>
					<h2 class="section-heading heading">Instagram</h2>
					
				</div>
				
			  </div>
			</div>
		  </div>
		</section>
		
		<div id="instagram-feed-container">
			<?php echo do_shortcode('[instagram-feed]'); ?>
		</div>
		
<?php get_footer(); ?>