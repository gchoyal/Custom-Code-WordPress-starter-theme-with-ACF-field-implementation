<?php 
/*
* Template Name: About
*/

get_header(); 

if( have_posts() ){ the_post(); ?>
	
	<section class="section" >
	  <div class="container">
		<div class="row">
		  
		  <div class="col-md-7 mx-auto text-left page-content">
			<?php the_content(); ?>
		  </div>
		  
		  <div class="col-md-5 mx-auto text-left">
				
				<?php 
				$img = get_the_post_thumbnail_url( get_the_ID(), 'full' );
				img( $img, '', '', 'About us' ); ?>
				
		  </div>
		  
		</div>
	  </div>
	</section>
	
<?php }

get_footer(); ?>