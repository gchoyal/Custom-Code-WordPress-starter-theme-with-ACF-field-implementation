<?php 
/*
* Template Name: Contact US
*/

get_header(); 

if( have_posts() ){ the_post(); ?>
	
	<section class="section" >
	  <div class="container">
		<div class="row">
		  
		  <div class="col-md-4 mx-auto text-left page-content">
		  
			<h2 class="heading">Contact us for any queries</h2>
			
			<div class="widget-container mb-4">							
				<p><a class="color-black" href="tel:<?php phone_number(); ?>"><i class="fal fa-phone fa-2x color-primary"></i> <?php phone_number('yes'); ?></a></p>
				<p><a class="color-black" href="mailto:<?php email_address(); ?>"><i class="fal fa-envelope mt-4 fa-2x color-primary"></i> <?php email_address(); ?></a></p>
			</div>

			<?php the_content(); ?>
		  </div>
		  
		  <div class="col-md-8 mx-auto text-left">
			
				<?php echo do_shortcode('[contact-form-7 id="5" title="Contact Page"]'); ?>
			
		  </div>
		  
		</div>
	  </div>
	</section>
	
<?php }

get_footer(); ?>