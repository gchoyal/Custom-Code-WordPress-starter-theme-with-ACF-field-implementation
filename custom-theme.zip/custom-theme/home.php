<?php get_header(); ?>

<div class="general-content-section pt-5 ">
	<div class="container">
		
		<div class="row">
		
			<?php if( have_posts() ): 
				
				while( have_posts() ): the_post(); ?>
				
					<div class="col-lg-4 col-md-4 col-sm-4 single-blog-post">
						<?php single_post_html(); ?>
					</div>
				
				<?php endwhile;
				
			endif; ?>
			
			<div class="col-lg-12 col-md-12 col-sm-12 blog-pagination text-center">

				<?php the_posts_pagination( array(
					'mid_size'  => 2,
					'prev_text' => __( '<i <i class="fas fa-angle-left"></i>', 'textdomain' ),
					'next_text' => __( '<i class="fas fa-angle-right"></i>', 'textdomain' ),
				) ); ?>
			
			</div>
			
		</div>
		
	</div>
</div>

<?php get_footer();