<?php 

add_filter( 'auto_update_plugin', '__return_true' );
function wp_custom_theme_add_woocommerce_support() {
    add_theme_support( 'woocommerce' );
	
	if( function_exists('acf_add_options_page') ) {
	
		acf_add_options_page(array(
			'page_title' 	=> 'Theme General Settings',
			'menu_title'	=> 'Theme Settings',
			'menu_slug' 	=> 'theme-general-settings',
			'capability'	=> 'edit_posts',
			'redirect'		=> false
		));
		
	}

}
add_action( 'after_setup_theme', 'wp_custom_theme_add_woocommerce_support' );

function wp_custom_theme_theme_name_scripts() {
	
	$rand = rand( 1, 9999 );
	
	wp_enqueue_style( 'style-bootstrap', get_template_directory_uri() . '/assets/vendors/bootstrap/css/bootstrap.min.css' );
	wp_enqueue_style( 'style-font-awesome', get_template_directory_uri() . '/assets/vendors/font-awesome/css/fontawesome-all.min.css' );
	wp_enqueue_style( 'style-magnific', get_template_directory_uri() . '/assets/vendors/magnific-popup/magnific-popup.css' );
    wp_enqueue_style( 'style-slick', get_template_directory_uri() . '/assets/vendors/slick/slick.css' );
	wp_enqueue_style( 'style-slick-theme', get_template_directory_uri() . '/assets/vendors/slick/slick-theme.css' );
    wp_enqueue_style( 'style', get_stylesheet_uri(), '', $rand  );
    
	wp_enqueue_script('jquery');
	wp_enqueue_script( 'jquery-ui-core' );
	wp_enqueue_script( 'script-bootstrap', get_template_directory_uri() . '/assets/vendors/bootstrap/js/bootstrap.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'script-images-loaded', get_template_directory_uri() . '/assets/vendors/images-loaded/imagesloaded.pkgd.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'script-magnific', get_template_directory_uri() . '/assets/vendors/magnific-popup/jquery.magnific-popup.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'script-slick', get_template_directory_uri() . '/assets/vendors/slick/slick.min.js', array(), '1.0.0', true );
	
	wp_enqueue_script( 'script-masonry', get_template_directory_uri() . '/assets/js/masonry.pkgd.min.js', array(), $rand, true );
	
	wp_enqueue_script( 'script-custom', get_template_directory_uri() . '/assets/js/script.js', array(), $rand, true );
	
}
add_action( 'wp_enqueue_scripts', 'wp_custom_theme_theme_name_scripts' );

function register_wp_custom_theme_menus() {
	
	//Theme Support
	add_theme_support( 'post-thumbnails' );
	
	//Menu Locations
	register_nav_menus( array(
		'header-menu' => __( 'Header Menu' ),
		'footer-first' => __( 'Footer First' ),
		'footer-secound' => __( 'Footer Second' )
	) );
	
}
add_action( 'init', 'register_wp_custom_theme_menus' );


//Add class to pagination links
add_filter('next_posts_link_attributes', 'posts_link_attributes');
add_filter('previous_posts_link_attributes', 'posts_link_attributes');

function posts_link_attributes() {
    return 'class="page-link btn"';
}

//Nav Menu Add class on LI element
add_filter ( 'nav_menu_css_class', 'wp_custom_theme_menu_item_class', 10, 4 );
function wp_custom_theme_menu_item_class ( $classes, $item, $args, $depth ){
  $classes[] = 'nav-item';
  return $classes;
}

//Nav Menu add class on each link (a)
function wp_custom_theme_add_specific_menu_location_atts( $atts, $item, $args ) {

    if( $args->theme_location == 'header-menu' ) {
      // add the desired attributes:
      $atts['class'] = 'nav-link';
    }
    return $atts;
}
add_filter( 'nav_menu_link_attributes', 'wp_custom_theme_add_specific_menu_location_atts', 10, 3 );

/*Translation: Start*/
//French language - black start remove 
function charencodeecho($text){
	
	$enc = mb_detect_encoding($text, "UTF-8,ISO-8859-1");

	return iconv($enc, "UTF-8", $text);
	
}

//Detect language 
function determine_text($text_english, $text_french, $echo = true){

	$language = get_bloginfo("language");
	
	if ($language == "fr-FR"){
		$text = charencodeecho($text_french);
	}elseif ($language == "en-US"){
		$text = charencodeecho($text_english);
	}

	if($echo){
		echo $text;
	}else{
		return $text;
	}
		
}

function multi_lang_permalink($pageid_english, $pageid_french){
	
	$language = get_bloginfo("language");
	
	if ($language == "fr-FR"){
		echo get_permalink($pageid_french);
	}elseif ($language == "en-US"){
		echo get_permalink($pageid_english);
	}
	
}
/*Translation: End*/

function social_media_links( $platform ){
	
	switch( $platform ){
		
		case 'facebook':
			$url = get_field('facebook', 'option');
			break;
		case 'twitter':
			$url = get_field('twitter', 'option');
			break;	
		case 'linkedin':
			$url = get_field('linkedin', 'option');
			break;
			
		case 'youtube':
			$url = get_field('youtube', 'option');
			break;
		
		case 'instagram':
			$url = get_field('instagram', 'option');
			break;
			
		default:
			$url = '';
		
	}
	
	echo $url;
	
}

function wp_custom_theme_social_media_html() {  ?>
<ul class="list-unstyled list-inline social text-center">
	<li class="list-inline-item"><a href="<?php social_media_links('facebook'); ?>" target="_blank" ><i class="fab fa-facebook-f"></i></a></li>
	<li class="list-inline-item"><a href="<?php social_media_links('twitter'); ?>" target="_blank" ><i class="fab fa-twitter"></i></a></li>
	<li class="list-inline-item"><a href="<?php social_media_links('linkedin'); ?>" target="_blank" ><i class="fab fa-linkedin-in"></i></a></li>
	<li class="list-inline-item"><a href="<?php social_media_links('youtube'); ?>" target="_blank" ><i class="fab fa-youtube"></i></a></li>
	<li class="list-inline-item"><a href="<?php social_media_links('instagram'); ?>" target="_blank" ><i class="fab fa-instagram"></i></a></li>
	
</ul>
<?php }


function img( $path, $class='', $caption='', $alt='Image' ){ ?> 
	
	<figure class="figure figure-custom-box <?php echo $class; ?>">
		<img src="<?php echo $path; ?>" class="figure-img img-fluid" alt="<?php echo $alt; ?>">
		<figcaption class="figure-caption <?php if( $caption == '' ){ echo 'd-none'; } ?>"><?php echo $caption; ?></figcaption>
	</figure>
	
<?php }

function single_post_html(){ ?> 
	
	<a href="<?php the_permalink(); ?>"><div class="blog-thumbnail" style="background: url(<?php the_post_thumbnail_url( get_the_ID(), 'full' ); ?>);"></div></a>

	<div class="blog-detail">

		<p><?php echo get_the_date('d M Y'); ?></p>
		<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		
	</div>
	
<?php }

function single_product(){ 
	
	global $product; 
	
	$img = get_the_post_thumbnail_url( get_the_ID(), 'medium' );
	$title = get_the_title();	?>
	
	<div class="col-lg-3 col-md-4 col-6 text-center">
		
		<div class="single-product-box">
			<a href="<?php echo get_permalink(); ?>">
			<div class="image-container">
				<?php img( $img, '', '', $title ); ?>
				<div class="overlay">
					
					<div class="overlay-content">
					<i class="fas fa-eye"></i>
					</div>
					
				</div>
			</div>
			</a>
			<a href="<?php echo get_permalink(); ?>">
			<div class="bottom-content">
				<p class="color-primary price-label"><?php echo $product->get_price_html(); ?></p>
				<p class="color-black"><?php echo $title; ?></p>
			</div> 
			</a>
			
		</div>
		
	</div>
	
<?php }

function get_list_texonomy( $texonomy ){
	
	if( is_product_category() ){
		
		$cate = get_queried_object();
		$cateID = $cate->term_id;
		
	}
	
	$proTerms = get_terms( array( 'taxonomy' => $texonomy, 'hide_empty' => false, 'exclude' => 60 ) ); 
	
	foreach( $proTerms as $proTrem ){ 
	
		if( isset($cateID) && $cateID == $proTrem->term_id ){
			$classActive = 'active';
		}else{
			$classActive = '';
		}
	
		?>
		
		<li class="category_link <?php echo $classActive; ?>"><a cat_id="<?php echo $proTrem->term_id; ?>" href="<?php echo get_term_link( $proTrem->term_id ); ?>"><?php echo $proTrem->name; ?></a></li>
		
	<?php }
	
}

//Ajax shop product listing
function product_listing_refresh(){
	
	$page_permalink = get_permalink();
	
	//recieve input 
	if( isset($_POST['pageno']) && $_POST['pageno']!='' ){
		$pageno = $_POST['pageno'];
	}else{
		$pageno = 1;
	}
	
	$per_page_product = $_POST['per_page_product'];
	$sort_by = $_POST['sort_by'];
	
	$pageID = get_option( 'woocommerce_shop_page_id' );
	
	$args = array(
				'post_type' => 		array('product'),
				'post_status' => 	'publish',
				'posts_per_page' => $per_page_product,
				'paged' => $pageno
			);
	
	switch ( $sort_by ) {
        case 'date':
            $args[] = array(
                'orderby' => 'date',
                'order' => 'DESC'
            );
            break;
        case 'price':
            $args[] = array(
                'orderby' => 'meta_value_num',
                'order' => 'ASC',
                'orderby_meta_key' => '_price'
            );
            break;
        case 'price-desc':
            $args[] = array(
                'orderby' => 'meta_value_num',
                'order' => 'DESC',
                'orderby_meta_key' => '_price'
            );
            break;
        case 'popularity':
            $args[] = array(
                'orderby' => 'meta_value_num',
                'order' => 'DESC',
                'orderby_meta_key' => 'total_sales'
            );
            break;
        /*case 'rating':
            $args[] = array(
                'orderby' => 'meta_value_num',
                'order' => 'DESC',
                'orderby_meta_key' => '_wc_average_rating'
            );
            break;
        default:*/
            
    }
	
	if( isset($_POST['activeCategory']) && $_POST['activeCategory']!='' ){
		
		$categoryTaxQuery = array(
								'taxonomy' => 'product_cat',
								'field'    => 'id',
								'terms'    => array( $_POST['activeCategory'] ),
								'operator' => 'IN'
							);
							
	}
	
	if( isset($_POST['aryActiveAttr']) && is_array($_POST['aryActiveAttr']) && count($_POST['aryActiveAttr']) > 0 ){
		
		$aryActiveAttr = $_POST['aryActiveAttr'];
			
		$aryListAttrNames = wp_list_pluck( $aryActiveAttr, 'attribute_name' );
		
		$aryUniqueListAttrNames = array_unique($aryListAttrNames);
		
		foreach( $aryUniqueListAttrNames as $arysingleUniqAttr ){
			
			$tmpAttrVal = array();
			foreach( $aryActiveAttr as $singleAttr ){
				
				if( $singleAttr['attribute_name'] == $arysingleUniqAttr ){
					$tmpAttrVal[] = $singleAttr['attribute_term'];
				}
			
			}
			
			$args['tax_query'][] = array(
									  'taxonomy'        => 'pa_' . $arysingleUniqAttr,
									  'field'           => 'slug',
									  'terms'           => $tmpAttrVal,
									  'operator'        => 'IN'
									);
			
		}
		
	}
	
	if( isset($categoryTaxQuery) ){
		$args['tax_query'][] = $categoryTaxQuery;
	}
	
	if( (isset($categoryTaxQuery) && ( isset($_POST['aryActiveAttr']) && is_array($_POST['aryActiveAttr']) && count($_POST['aryActiveAttr']) > 0) )
		|| ( isset($_POST['aryActiveAttr']) && is_array($_POST['aryActiveAttr']) && count($_POST['aryActiveAttr']) > 1 ) ){
			
			$args['tax_query'][] = array( 'relation' => 'AND' );
			
	}
	
	//echo '<pre>'; print_r($args); die(0);
	
	query_posts( $args );  ?>
	  
	<!--Listing-->
	<?php if( have_posts() ){ 
			while( have_posts() ){ the_post(); single_product( $pageID ); } 
		}else{ ?>
			<div class="col-lg-12 mt-5 mb-5 text-center"><p>No Product Available!</p></div>
		<?php } ?>
	
	<!--Pagination-->
	<div class="col-lg-12 col-md-12 col-sm-12 text-center">
		
		<nav>
		  <ul class="pagination justify-content-center">
			
			<?php if( get_previous_posts_link() ){ ?>
			<li class="page-item">
				<a href="#" pageno="<?php echo ($pageno-1); ?>" class="page-link">PREVIOUS</a>
			</li>
			<?php } ?>
			
			<?php if( get_next_posts_link() ){ ?>
			<li class="page-item">
			  <a href="#" pageno="<?php echo ($pageno+1); ?>" class="page-link">NEXT</a>
			</li>
			<?php } ?>
			
		  </ul>
		</nav>

	</div>
	
	<?php die(0);
	
}
add_action( 'wp_ajax_product_listing_refresh', 'product_listing_refresh' );
add_action( 'wp_ajax_nopriv_product_listing_refresh', 'product_listing_refresh' );

function loader_html(){ ?>
	
	<div class="page-loader">
		<div class="row">
		  <a href="#" class="intro-banner-vdo-play-btn pinkBg" >
			<i class="glyphicon glyphicon-play whiteText" aria-hidden="true"></i>
			<span class="ripple pinkBg"></span>
			<span class="ripple pinkBg"></span>
			<span class="ripple pinkBg"></span>
		  </a>
		</div>
	</div>  
	
<?php }

function loader_spinner(){ ?>
	
	<i class="fas fa-spinner fa-spin color-primary product-filter-atrr-loader"></i>
	
<?php }

//searchfilter
function searchfilter($query) {
 
    if ($query->is_search && !is_admin() ) {
        $query->set('post_type',array( 'product', 'post', 'page' ));
    }
 
	return $query;
}
add_filter('pre_get_posts','searchfilter');

function price_n_badge( $pID ){
	
	$_product = wc_get_product( $pID );
	$salePrice = $_product->get_sale_price();
	$rPrice = $_product->get_regular_price();
	$percentage = '';

	if( $salePrice != '' && $rPrice != '' ){
		
		//Count Sale
		$percentage = round( ( $rPrice - $salePrice ) / $rPrice * 100 ).'%';
		
		$priceHTML = '<label class="label label-warning product-price">'.wc_price($salePrice).'<sm>'.wc_price($rPrice).'</sm></label>';

	}elseif( $salePrice == '' && $rPrice != '' ){
		$priceHTML = '<label class="label label-warning product-price">'.wc_price($rPrice).'</label>';
	}else{
		$priceHTML = '';
	}

	if( $percentage != '' ){
		$badge = '<label class="label label-primary deal-type">-'. $percentage .'</label>';
	}else{
		$badge = '';
	}
	
	return array( 'price' => $priceHTML, 'badge' => $badge );
	
}

function custom_logo_url(){	the_field('header_logo', 'option'); }
function custom_footer_logo_url(){	the_field('footer_logo', 'option'); }

function phone_number( $formated = '' ){

	if( $formated == 'yes' ){
		the_field('phone_formated', 'option');
	}else{
		the_field('phone_plain', 'option');
	}
	
}

function email_address(){
	the_field('email', 'option');
}

function address( $google = '' ){
	if( $google == 'yes' ){
		the_field('address_link', 'option');
	}else{
		the_field('address_text', 'option');
	}
}

function wp_custom_theme_footer_scripts() { 

	$current_user = wp_get_current_user();
	
	if ( user_can( $current_user, 'administrator' ) ) { ?>
	
	<style>header.fixed-top{ top: 31px; }</style>
	
	<?php } ?>
    
	<script>
		var ajax_url = '<?php echo admin_url( 'admin-ajax.php' ); ?>';
	</script>
	
	<?php
	
}
add_action( 'wp_footer', 'wp_custom_theme_footer_scripts' );

add_action('admin_menu', 'remove_options'); 
function remove_options() { //remove Blog
    //remove_menu_page( 'edit.php' );
    remove_menu_page( 'edit-comments.php' );
	remove_menu_page( 'link-manager.php' );
}

//login redirect 
function wp_custom_theme_login_redirect( $redirect, $user ) {
    return wc_get_page_permalink( 'shop' );
}
add_filter( 'woocommerce_login_redirect', 'wp_custom_theme_login_redirect', 10, 2 );

//Nav Menu Bootstrap 
class My_Custom_Nav_Walker extends Walker_Nav_Menu {

   function start_lvl(&$output, $depth = 0, $args = array()) {
      $output .= "\n<ul class=\"dropdown-menu\">\n";
   }

   function start_el(&$output, $item, $depth = 0, $args = array(), $id = 0) {
       $item_html = '';
       parent::start_el($item_html, $item, $depth, $args);

       if ( $item->is_dropdown && $depth === 0 ) {
           $item_html = str_replace( '<a', '<a class="dropdown-toggle nav-link"', $item_html );
           $item_html = str_replace( '</a>', ' <b class="caret"></b></a>', $item_html );
       }

       $output .= $item_html;
    }

    function display_element($element, &$children_elements, $max_depth, $depth = 0, $args, &$output) {
	
        if ( $element->current )
        $element->classes[] = 'active';

        $element->is_dropdown = !empty( $children_elements[$element->ID] );

        if ( $element->is_dropdown ) {
            if ( $depth === 0 ) {
                $element->classes[] = 'dropdown nav-item';
            } elseif ( $depth === 1 ) {
      
                $element->classes[] = 'dropdown-submenu';
				
            }
        }

		parent::display_element($element, $children_elements, $max_depth, $depth, $args, $output);
	
    }
}

