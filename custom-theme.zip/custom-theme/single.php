<?php get_header(); ?>

<div class="general-content-section single-post-content">
	<div class="container">
		
		<div class="row">
		
			<div class="col-lg-12 col-md-12 col-sm-12 text-center mt-5">
		
				<?php if( have_posts() ): the_post(); ?>
					
					<?php the_post_thumbnail( 'large' ); ?>
					
					<div class="pt-5">
					<?php the_content();  ?>
					</div>
					
				<?php endif; ?>
				
			</div>
			
		</div>
		
	</div>
</div>

<div class="general-content-section text-center my-5">
	<div class="container">
	
		<h2 class="text-center mb-5">Related Articles</h2>
		
		<div class="row text-left">
			
			<?php $args = array(
				'numberposts' => 4,
				'orderby' => 'post_date',
				'order' => 'DESC',
				'post_type' => 'post',
				'post_status' => 'publish',
				'exclude' => get_the_ID(),
				'suppress_filters' => true
			);

			$recent_posts = wp_get_recent_posts( $args, ARRAY_A );
			
			foreach( $recent_posts as $recent ){ ?>
			
			<div class="col-lg-3 col-md-3 col-sm-3 single-blog-post">
				
				<?php single_post_html( $recent ); ?>
				
			</div>
			
			<?php } wp_reset_query(); ?>
			
		</div>
		
		<a href="<?php the_permalink( get_option( 'page_for_posts' ) ); ?>" class="btn btn-primary view-more">VIEW MORE</a>
		
	</div>
</div>

<?php get_footer();