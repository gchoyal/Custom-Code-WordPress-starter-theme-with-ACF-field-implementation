		<?php if( !is_post_type_archive( 'product' ) && !is_product_category() ){ ?>
		<section class="section section-graphic-background shop-collection-section" >
		  <div class="container">
			
			<div class="row">
				
				<div class="col-md-10 left-section text-left">
					<h2>Shop the collection</h2>
				</div>
				<div class="col-md-2 right-section text-right">
					<a class="btn btn-primary btn-shop-now" href="<?php echo get_permalink( get_option( 'woocommerce_shop_page_id' ) ); ?>">Shop Now</a>
				</div>
			</div>
			
		  </div>
		</section>
		<?php } ?>
		
		<footer class="onescroll-section background-dark">
			<div class="container">
				<div class="row text-center text-xs-center text-sm-left text-md-left">
					<div class="col-md-6 col-lg-3 widget-container widget-container-logo">
						
						<div class="logo-container">
							<a href="<?php echo home_url(); ?>">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/logo.png" class="logo background-lightdark" >
							</a>
						</div>
						
						<?php wp_custom_theme_social_media_html(); ?>
						
						</hr>
						
					</div>
					<div class="col-md-6 col-lg-3 widget-container">
						<h5 class="color-primary">COMPANY</h5>
						
						<?php wp_nav_menu( array( 
							'theme_location' => 'footer-first',
							'menu_class' => 'list-unstyled quick-links',
							'container' => '',
							'before' => ''
						) ); ?>
						
					</div>
					<div class="col-md-6 col-lg-3 widget-container">
						<h5 class="color-primary">SITEMAP</h5>
						
						<?php wp_nav_menu( array( 
							'theme_location' => 'footer-secound',
							'menu_class' => 'list-unstyled quick-links',
							'container' => '',
							'before' => ''
						) ); ?>
						
					</div>
					<div class="col-md-6 col-lg-3 widget-container">
						
						<h5 class="color-primary">Connect with us</h5>
						<div class="widget-container mb-0">
							
							<p><a href="<?php address('yes'); ?>" target="_blank"><i class="fal fa-map-marker-alt fa-2x"></i> <?php address(); ?></a></p>
							<p><a href="tel:<?php phone_number(); ?>"><i class="fal fa-phone fa-2x"></i> <?php phone_number('yes'); ?></a></p>
							<p><a href="mailto:<?php email_address(); ?>"><i class="fal fa-envelope fa-2x"></i> <?php email_address(); ?></a></p>
					
						</div>
						
					</div>
					
					<div class="foooter-inner-bottom  widget-container">
						
						<div class="subscribe-box background-lightdark">
							<p class="text-uppercase color-primary newsletter-heading" >Newsletter</p>
							<div class="input-group">
								<?php echo do_shortcode('[contact-form-7 id="7" title="Subscription"]'); ?>
							</div>
						</div>
						<img class="card-img" src="<?php echo get_template_directory_uri(); ?>/assets/img/payment_methods_logos.png">
					</div>
					
					
				</div>
				
				
			</div>
			
			<div class="row footer-bottom background-lightdark">
				<div class="container">
					<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-2 text-center">
						<p class="h5">Copyright &copy <?php echo date('Y'); ?> <a href="<?php echo home_url(); ?>">Girdhari Choyal</a> . All Right Reserved.</p>
					    
						<div class="createdbycredit">
						<a href="http://shivaywebsystems.com/" target="blank" class="createdbycredit-link">Created by Shivay Web Systems</a>
						</div>

					</div>
				</div>
			</div>	
			
		</footer>
		
		
	</div>
	
	<div id="search-form-container" class="text-center">
		<a href="#" class="search-close"><i class="fal fa-times"></i></a>
		<div class="container">
			<div class="row">
				
				<div class="col-md-5 col-md-offset-8 search-form" >
					<form action="<?php echo home_url(); ?>">
					<div class="input-group mb-3">
					  
					  <input type="text" name="s" class="form-control" placeholder="Search..." autofocus>
					  <div class="input-group-append">
						<button class="btn" type="submit"><i class="fas fa-search"></i></button>
					  </div>
					 
					</div>
					 </form>
				</div>
				
			</div>
		</div>
		
	</div>
	
	<a href="#main" id="back-to-top" class="js-scroll-trigger"><i class="fal fa-angle-up"></i></a>
	
	<?php wp_footer(); ?>
	
</body>
</html>