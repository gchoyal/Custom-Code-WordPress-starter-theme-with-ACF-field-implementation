<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Girdhari Choyal</title>
	
	<?php wp_head(); ?>

</head>

<body <?php body_class(); ?>>

	<header class="fixed-top">
		
		<div class="topbar">
			<div class="container">
				<div class="row">
				
					<div class="col-lg-6 web-only">
						FREE DELIVERY ON $250. EXCLUSIONS APPLY. Code DELIVERY250. <a href="#" class="hightlight-text">Details</a>
					</div>
					
					<div class="col-lg-6 right-section text-right">
						
						<?php wp_custom_theme_social_media_html(); ?>
						
						<?php if( !is_user_logged_in() ){ ?>
							<p class="web-only"><a href="<?php echo get_permalink( wc_get_page_id( 'myaccount' ) ); ?>">Sign in</a> or <a href="<?php echo get_permalink( 1256 ); ?>">Create account</a></p>
						<?php } ?>
						
					</div>
				
				</div>
			</div>
		</div>
		
		<!-- Navigation -->
		<nav class="navbar navbar-expand-lg navbar-light background-white">
		  <div class="container">
			<a class="navbar-brand js-scroll-trigger" href="<?php echo home_url(); ?>"><img src="<?php echo custom_logo_url(); ?>" class="logo" ></a>
			<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
			  <i class="fal fa-bars"></i>
			</button>
			
			<div class="nav-right-extra-links">
				
				<ul>
					<li>
					  <a href="#" class="search-link"><i class="fal fa-search"></i></a>
					</li>
					<li>
					  <div class="dropdown">
						  
						  <a href="#" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						  <i class="fal fa-user-circle"></i></a>
						  
						  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
							<?php if( is_user_logged_in() ){ ?>
							<a class="dropdown-item" href="<?php echo get_permalink( wc_get_page_id( 'myaccount' ) ); ?>">My Account</a>
							<a class="dropdown-item" href="<?php echo get_permalink( wc_get_page_id( 'myaccount' ) ); ?>/orders">Orders</a>
							<a class="dropdown-item" href="<?php echo wp_logout_url( home_url() ); ?>">Logout</a>
							<?php }else{ ?>
							<a class="dropdown-item" href="<?php echo get_permalink( wc_get_page_id( 'myaccount' ) ); ?>">Sign in</a>
							<a class="dropdown-item" href="<?php echo get_permalink( 1256 ); ?>">Sign up</a>
							<?php } ?>
						  </div>
					  
					  </div>
					  
					</li>
					<li>
					  <a href="<?php echo wc_get_cart_url(); ?>" id="shopping-cart-link"><i class="fal fa-shopping-cart"></i> <span><?php echo WC()->cart->get_cart_contents_count(); ?></span></a>
					</li>
				</ul>
				
			</div>
			
			<div class="collapse navbar-collapse" id="navbarResponsive">
				<?php wp_nav_menu( array( 
						'theme_location' => 'header-menu',
						'menu_class' => 'navbar-nav ml-auto',
						'container' => '',
						'walker'	=> new My_Custom_Nav_Walker
						
					) ); ?>
			</div>
			
			
			
		  </div>
		</nav>
	</header>
	
	<div class="main" id="main">
	
		<?php if( !is_front_page() && !is_404() ){ ?>
		
			<div class="page-header text-center text-white">
				<div class="container">
					<div class="row">
						
						<h1><?php if( is_search() ){ echo 'Search Result: '. get_search_query(); }elseif( is_woocommerce() && !is_product() ){ woocommerce_page_title(); }else{ the_title(); } ?></h1>
						
					</div>
				</div>
			</div>
			
		<?php } ?>