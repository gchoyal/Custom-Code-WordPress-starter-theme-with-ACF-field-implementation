<?php get_header(); 

if( have_posts() ){ the_post(); ?>
	
	<section class="section section-graphic-background" >
	  <div class="container">
		<div class="row">
		  <div class="col-lg-12 mx-auto text-left">
			
				<?php the_content(); ?>
			
		  </div>
		</div>
	  </div>
	</section>
	
<?php }

get_footer(); ?>