<?php get_header();

global $wp_query;
$total_results = $wp_query->found_posts; ?>
	
	<section class="section" >
	  <div class="container">
		<div class="row">
		  <div class="col-lg-12 mx-auto text-left">
			
			<div class="section-header">
				<div class="row search-box-container">
					<div class="col-lg-6 left-side">
						<h4>Found <?php echo $total_results; ?> Results</h4>
					</div>
					<div class="col-lg-6 text-right right-side">
						<?php get_search_form(); ?>
					</div>
				</div>
			</div>
			
			<div class="row product-listing-row">
				
				<?php if( have_posts() ){
					
					while( have_posts() ){ the_post();
						single_product();
					}
				
				}else{ ?>
					<div class="col-lg-12 text-center">
						<p class="mt-4 mb-4 text-center">No Result Found.</p>
					</div>
				<?php } ?>
				
			</div>
			
			<nav>
			  <ul class="pagination justify-content-center">
				<li class="page-item"><?php previous_posts_link(); ?></li>
				<li class="page-item"><?php next_posts_link(); ?></li>
			  </ul>
			</nav>

		  </div>
		</div>
	  </div>
	</section>
	
<?php get_footer(); ?>