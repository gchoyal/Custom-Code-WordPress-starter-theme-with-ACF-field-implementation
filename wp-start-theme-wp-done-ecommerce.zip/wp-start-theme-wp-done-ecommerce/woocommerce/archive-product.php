<?php get_header(); 
	
	$pageID = get_option( 'woocommerce_shop_page_id' );  ?>
	
		<section class="section" >
		  <div class="container">
			
			<div class="row">
				
				<!--Filter-->
				
				<div class="col-lg-12 text-center">
					
					<a href="#" id="shop-filter-link-mobile">FILTER <i class="fal fa-filter"></i></a>
					
				</div>
				
				<div class="col-lg-12 text-right shop-filter-container-mobile">
					
					<div class="input-group mb-3 product-filter-input">
					  
					  <div class="input-group-prepend">
						<span class="input-group-text" id="basic-addon1">Show</span>
					  </div>
					  
					  <select class="form-control filter-input-select" id="per-page-product">
							<option value="20" >20</option>
							<option value="40" >40</option>
							<option value="60" >60</option>
							<option value="80" >80</option></select>
							
							<?php loader_spinner(); ?>
					  
					</div>
					
					<div class="input-group mb-3 product-filter-input"> 
					  
					  <div class="input-group-prepend">
						<span class="input-group-text" id="basic-addon1">Sort By</span>
					  </div>
					  
					  <select class="form-control filter-input-select" id="sort-by">
							<option value="menu_order" >Default</option>
							<option value="popularity" >Popularity</option>
							<option value="date" >Latest</option>
							<option value="price" >Price - ASC</option>
							<option value="price-desc" >Price - DESC</option></select>
							
							<?php loader_spinner(); ?>
					  
					  
					</div>
					
				</div>
				
				<div class="col-lg-2 col-md-2 left-sidebar-filter">
					
					
					<div class="shop-filter-container-mobile">
					
					<h4 class="undrline-heading">CATEGORIES <i class="far fa-angle-down"></i></h4>
					<ul><?php get_list_texonomy( 'product_cat' ); ?></ul>
					
					<?php 
					
					$attribute_taxonomies = wc_get_attribute_taxonomies();
					
					if ( $attribute_taxonomies ){
						foreach ( $attribute_taxonomies as $tax ){
							if ( taxonomy_exists( wc_attribute_taxonomy_name( $tax->attribute_name ) ) ){
								
								$terms = get_terms( wc_attribute_taxonomy_name($tax->attribute_name), array( 'hide_empty' => false ) );
								
								if( count($terms) > 0 ){
								
									?><h4 class="undrline-heading product-attr-heading"><?php echo $tax->attribute_label; ?> <i class="far fa-angle-down"></i></h4>
									
									<ul>
									<?php 
									
									foreach ( $terms as $term ){
										
										?><li><a href="#" class="attribute" attribute_name="<?php echo $tax->attribute_name; ?>" attribute_term="<?php echo $term->slug; ?>" ><i class="fal fa-square"></i> <?php echo $term->name; ?></a> <?php loader_spinner(); ?><li><?php 
										
									}
									
									?></ul><?php
									
								}
								
							}
						}
					}
					
					?>
					
					</div>
				</div>
				
				<div class="col-lg-10 col-md-10">
					
					<div class="row product-listing-row">
						
						<!--Notification-->
						<?php if( isset($_GET['add-to-cart']) && intval($_GET['add-to-cart']) >0 ){ ?><div class="col-md-12 col-sm-12"><?php wc_print_notices(); ?></div><?php } ?>
						
						<!--Listing-->
						<?php if( have_posts() ){ 
								while( have_posts() ){ the_post(); single_product( $pageID ); } 
							}else{ ?>
								<div class="col-lg-12 mt-5 mb-5 text-center"><p>No Product Available!</p></div>
							<?php } ?>
						
						<!--Pagination-->
						<div class="col-lg-12 col-md-12 col-sm-12 text-center">
							
							<nav>
							  <ul class="pagination justify-content-center">
								
								<?php if( get_next_posts_link() ){ ?>
								<li class="page-item">
									<a href="#" pageno="2" class="page-link">NEXT</a>
								</li>
								<?php } ?>
								
							  </ul>
							</nav>

						</div>
						
					</div>
				</div>
			
			</div>
			
		  </div>
		</section>
		
<?php get_footer(); ?>