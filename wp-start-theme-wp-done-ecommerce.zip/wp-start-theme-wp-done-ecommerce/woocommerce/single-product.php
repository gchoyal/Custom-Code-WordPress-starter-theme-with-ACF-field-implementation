<?php get_header(); 

//GET FEATURE IMAGE
$imageURL = get_the_post_thumbnail_url( get_the_ID(), 'full' );

$_product = wc_get_product( get_the_ID() );

$attachment_ids = $_product->get_gallery_image_ids();


if( have_posts() ){ the_post(); ?>
	
	<section class="section section-graphic-background" >
	  <div class="container">
		<div class="row">
		  <div class="col-lg-7 text-center popup-gallery">
			
			<a title="<?php the_title(); ?>" href="<?php echo $imageURL; ?>"><img class="img-responsive" src="<?php echo $imageURL; ?>"></a>
			
			<div id="gallery-thumbnails">
			
			<?php foreach( $attachment_ids as $attachment_id ) { ?>
					
					<a title="<?php the_title(); ?>" href="<?php echo wp_get_attachment_url( $attachment_id ); ?>"><img class="img-responsive" src="<?php echo wp_get_attachment_url( $attachment_id ); ?>"></a>
			
			<?php } ?>
			
			</div>
			
		  </div>
		  <div class="col-lg-5 text-left content">
				
				<?php do_action( 'woocommerce_single_product_summary' ); ?>
				
				<div class="product-content">
				<?php the_content(); ?>
				</div>
			
		  </div>
		  
		  <?php $arrayRelatedProducts = wc_get_related_products( get_the_ID(), 4 );
			
			if( count($arrayRelatedProducts) > 0 ){ ?>
		  
				<hr>
			  
				<div class="col-md-12 section-header text-center related-header" >
					<h1 class="section-heading heading">RELATED PRODUCTS</h1>
				</div>
		  
				<?php foreach( $arrayRelatedProducts as $post){
				
					setup_postdata($post);

					single_product();
				
				}
			
				wp_reset_postdata();
		  
			} ?>
		  
		</div>
	  </div>
	</section>
	
<?php }

get_footer(); ?>