<?php get_header(); 
	
	$pageID = get_the_ID();
	
?>
	
		<div id="home-slider" class="carousel carousel-fade slide" data-ride="carousel">

		  <div class="carousel-inner">
			
			<?php if( have_rows('slide') ):
			    $i=1;
			    while ( have_rows('slide') ) : the_row(); ?>
			    
			<div class="carousel-item overlay <?php if( $i == 1 ){ echo 'active'; } ?>">
			  <img src="<?php the_sub_field('image'); ?>" alt="joseph zurdock">
			  <div class="carousel-caption">
					<div class="col-md-12 slide-content-container">
						<h1 style="color:<?php the_sub_field('text_color_code'); ?>;" class="heading"><?php the_sub_field('heading_html'); ?></h1>
						<a href="<?php echo get_permalink( get_option( 'woocommerce_shop_page_id' ) ); ?>" class="browse-link">Shop Now</a>
					</div>
				</div>
			</div>
			
			<?php $i++; endwhile; endif; ?>
			
			
		  </div>

		  <a class="carousel-control-prev" href="#home-slider" data-slide="prev"><span>PR</span><span>EV</span></a>
		  <a class="carousel-control-next" href="#home-slider" data-slide="next"><span>NE</span><span>XT</span></a>

		</div>
		
		<section class="section" >
		  <div class="container">
			<div class="row">
			  <div class="col-lg-12 mx-auto text-left">
				
				<div class="section-header text-center">
					<p><a href="<?php echo get_permalink( get_option( 'woocommerce_shop_page_id' ) ); ?>" class="color-primary">Just in to store</a></p>
					<h1 class="section-heading heading">Must Have</h1>
					<p>Lowest priced item is free. Exludes clearance.</p>
				</div>
				
				<div class="row product-listing-row">
					
					<?php if( isset($_GET['add-to-cart']) && intval($_GET['add-to-cart']) >0 ){ ?>
					<div class="col-md-12 col-sm-12">
						<?php wc_print_notices(); ?>
					</div>
					<?php } ?>
	
					<?php 
					
					query_posts('post_type=product&post_status=publish&orderby=date&posts_per_page=12');
					
					if( have_posts() ){
					
					while( have_posts() ){ the_post();
					
						single_product( $pageID );
					
					} } 
					
					wp_reset_query(); ?>
					
				</div>
				
			  </div>
			</div>
		  </div>
		</section>
		
		<section class="section" id="instagram-feed-container" style="display: none !important;">
		  <div class="container">
			<div class="row">
			  <div class="col-lg-12 mx-auto text-left">
				
				<div class="section-header text-center">
					<p><a href="#" class="color-primary">Follow us @</a></p>
					<h1 class="section-heading heading">Instagram</h1>
					
				</div>
				
				<div class="row">
					
					<?php echo do_shortcode('[instagram-feed]'); ?>
					
				</div>
				
			  </div>
			</div>
		  </div>
		</section>
		
<?php get_footer(); ?>