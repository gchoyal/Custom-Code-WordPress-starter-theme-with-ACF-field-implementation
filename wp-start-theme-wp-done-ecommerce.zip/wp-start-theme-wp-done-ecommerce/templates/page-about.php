<?php 
/*
* Template Name: About
*/

get_header(); 

if( have_posts() ){ the_post(); ?>
	
	<section class="section section-graphic-background" >
	  <div class="container">
		<div class="row">
		  
		  <div class="col-md-7 mx-auto text-left page-content">
			<?php the_content(); ?>
		  </div>
		  
		  <div class="col-md-5 mx-auto text-left">
			
				<img class="img-responsive" src="<?php echo get_the_post_thumbnail_url( get_the_ID(), 'full' ); ?>">
			
		  </div>
		  
		</div>
	  </div>
	</section>
	
	
	<div class="col-sm-12 col-md-12 col-lg-12 background-gray about-services-box">
			
		<div class="container">
			<div class="row">
					<div class="col-sm-12 col-md-12 col-lg-4 box silver-box">
						
						<div class="row">
							<div class="col-sm-12 col-md-12 col-lg-3 text-center">
								<i class="fal fa-gift fa-3x"></i>
							</div>
							<div class="col-sm-12 col-md-12 col-lg-9 mobile-text-align">
								<p class="box-heading"><strong>GIFTS FOR LOVED ONES</strong></p>
								<p>Whether it is for a one time father's Day or borthday gift, or whether you simply want to thank you groomsmen for being awesome, the possibilities are endless with GC</p>
							</div>
						</div>
						
					</div>
					<div class="col-sm-12 col-md-12 col-lg-4 box pink-box">
						
						<div class="row">
							<div class="col-sm-12 col-md-12 col-lg-3 text-center">
								<i class="fal fa-shipping-fast fa-3x"></i>
							</div>
							<div class="col-sm-12 col-md-12 col-lg-9 mobile-text-align">
								<p class="box-heading"><strong>FREE SHIPPINGS</strong></p>
								<p>Our simple subscription packages have become even simpler!  With <b>free shipping across North America</b>, you won?t get caught with any additional surprise charges!</p>
							</div>
						</div>
						
					</div>
					<div class="col-sm-12 col-md-12 col-lg-4 box silver-box">
						
						<div class="row">
							<div class="col-sm-12 col-md-12 col-lg-3 text-center">
								<i class="fal fa-thumbs-up fa-3x"></i>
							</div>
							<div class="col-sm-12 col-md-12 col-lg-9 mobile-text-align">
								<p class="box-heading"><strong>FOLLOW US</strong></p>
								<p>At GC, we love to give! Like and follow us on <a href="<?php social_media_links('facebook'); ?>" target="_blank">Facebook</a> and <a href="<?php social_media_links('instagram'); ?>" target="_blank">Instagram</a> $5 discount code</p>
							</div>
						</div>
						
					</div>
			</div>
		</div>
		
	</div>
	
<?php }

get_footer(); ?>