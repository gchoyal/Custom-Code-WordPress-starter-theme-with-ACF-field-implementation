<?php 
/*
* Template Name: Contact US
*/

get_header(); 

if( have_posts() ){ the_post(); ?>
	
	<section class="section section-graphic-background" >
	  <div class="container">
		<div class="row">
		  
		  <div class="col-md-4 mx-auto text-left page-content">
			<?php the_content(); ?>
		  </div>
		  
		  <div class="col-md-8 mx-auto text-left">
			
				<?php echo do_shortcode('[contact-form-7 id="12" title="Contact Form"]'); ?>
			
		  </div>
		  
		</div>
	  </div>
	</section>
	
<?php }

get_footer(); ?>